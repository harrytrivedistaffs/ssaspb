<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/contrib/localgov_base/templates/content/node--localgov-news-article--full.html.twig */
class __TwigTemplate_a24582a459de3d47bcb5372ceea5b21b extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 68
        yield "
";
        // line 70
        $context["classes"] = ["news-article", "node", ("node--type-" . \Drupal\Component\Utility\Html::getClass(CoreExtension::getAttribute($this->env, $this->source,         // line 73
($context["node"] ?? null), "bundle", [], "any", false, false, true, 73))), (((($tmp = CoreExtension::getAttribute($this->env, $this->source,         // line 74
($context["node"] ?? null), "isPromoted", [], "method", false, false, true, 74)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("node--promoted") : ("")), (((($tmp = CoreExtension::getAttribute($this->env, $this->source,         // line 75
($context["node"] ?? null), "isSticky", [], "method", false, false, true, 75)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("node--sticky") : ("")), (( !(($tmp = CoreExtension::getAttribute($this->env, $this->source,         // line 76
($context["node"] ?? null), "isPublished", [], "method", false, false, true, 76)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("node--unpublished") : ("")), (((($tmp =         // line 77
($context["view_mode"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (("node--view-mode-" . \Drupal\Component\Utility\Html::getClass(($context["view_mode"] ?? null)))) : (""))];
        // line 80
        yield "
";
        // line 81
        if ( !(($tmp = ($context["localgov_base_remove_css"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 82
            yield "  ";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("localgov_base/news"), "html", null, true);
            yield "
";
        }
        // line 84
        yield "
<article";
        // line 85
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [($context["classes"] ?? null)], "method", false, false, true, 85), "html", null, true);
        yield ">
  <div class=\"lgd-container padding-horizontal\">
    <div class=\"lgd-row\">
      <div class=\"lgd-row__two-thirds\">
        <div class=\"news-article__metadata\">
          <time datetime=\"";
        // line 90
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["node"] ?? null), "localgov_news_date", [], "any", false, false, true, 90), "value", [], "any", false, false, true, 90), "html", null, true);
        yield "\" class=\"news-article__metadata-item news-article__metadata-item--date\">
            ";
        // line 91
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, (($_v0 = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "localgov_news_date", [], "any", false, false, true, 91), 0, [], "any", false, false, true, 91)) && is_array($_v0) || $_v0 instanceof ArrayAccess && in_array($_v0::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v0["#markup"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "localgov_news_date", [], "any", false, false, true, 91), 0, [], "any", false, false, true, 91), "#markup", [], "array", false, false, true, 91)), "html", null, true);
        yield "
          </time>
          ";
        // line 93
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["node"] ?? null), "localgov_news_categories", [], "any", false, false, true, 93), "value", [], "any", false, false, true, 93)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 94
            yield "            <ul class=\"news-article__metadata-item news-article__metadata-item--categories\" aria-label=\"";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Article categories"));
            yield "\">
              ";
            // line 95
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["node"] ?? null), "localgov_news_categories", [], "any", false, false, true, 95), "value", [], "any", false, false, true, 95));
            foreach ($context['_seq'] as $context["key"] => $context["value"]) {
                // line 96
                yield "                <li class=\"news-article__category\">
                  ";
                // line 97
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, (($_v1 = CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "localgov_news_categories", [], "any", false, false, true, 97)) && is_array($_v1) || $_v1 instanceof ArrayAccess && in_array($_v1::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v1[(($_v2 = $context["key"]) instanceof \Stringable ? (string) $_v2 : $_v2)] ?? null) : CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "localgov_news_categories", [], "any", false, false, true, 97), $context["key"], [], "array", false, false, true, 97)), "html", null, true);
                yield "
                </li>
              ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['key'], $context['value'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 100
            yield "            </ul>
          ";
        }
        // line 102
        yield "        </div>

        <h1";
        // line 104
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["title_attributes"] ?? null), "addClass", ["news-article__title"], "method", false, false, true, 104), "html", null, true);
        yield ">
          ";
        // line 105
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["label"] ?? null), "html", null, true);
        yield "
        </h1>

        <div";
        // line 108
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["content_attributes"] ?? null), "addClass", ["news-article__content node__content"], "method", false, false, true, 108), "html", null, true);
        yield ">

          ";
        // line 110
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->withoutFilter(($context["content"] ?? null), "localgov_news_date", "localgov_news_categories", "localgov_news_related"), "html", null, true);
        yield "

          ";
        // line 112
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["node"] ?? null), "localgov_news_related", [], "any", false, false, true, 112), "value", [], "any", false, false, true, 112)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 113
            yield "            <h2 class=\"news-article__related-title\">";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Related news"));
            yield "</h2>
            ";
            // line 114
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "localgov_news_related", [], "any", false, false, true, 114), "html", null, true);
            yield "
          ";
        }
        // line 116
        yield "
        </div>
      </div>
    </div>
  </div>

</article>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["node", "view_mode", "localgov_base_remove_css", "attributes", "content", "title_attributes", "label", "content_attributes"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/contrib/localgov_base/templates/content/node--localgov-news-article--full.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  149 => 116,  144 => 114,  139 => 113,  137 => 112,  132 => 110,  127 => 108,  121 => 105,  117 => 104,  113 => 102,  109 => 100,  99 => 97,  96 => 96,  92 => 95,  87 => 94,  85 => 93,  80 => 91,  76 => 90,  68 => 85,  65 => 84,  59 => 82,  57 => 81,  54 => 80,  52 => 77,  51 => 76,  50 => 75,  49 => 74,  48 => 73,  47 => 70,  44 => 68,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "themes/contrib/localgov_base/templates/content/node--localgov-news-article--full.html.twig", "/Users/harshtrivedi/LocalGov Drupal SCC/ssaspb/web/themes/contrib/localgov_base/templates/content/node--localgov-news-article--full.html.twig");
    }
    
    public function ensureSecurityChecked(): void
    {
        if ($this->sandbox->isSandboxed($this->source)) {
            $this->checkSecurity();
        }
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 70, "if" => 81, "for" => 95];
        static $filters = ["clean_class" => 73, "escape" => 82, "t" => 94, "without" => 110];
        static $functions = ["attach_library" => 82];
        static $tests = [];

        try {
            $this->sandbox->checkSecurity(
                [0 => "set", 1 => "if", 2 => "for"],
                [0 => "clean_class", 1 => "escape", 2 => "t", 3 => "without"],
                [0 => "attach_library"],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            } elseif ($e instanceof SecurityNotAllowedTestError && isset($tests[$e->getTestName()])) {
                $e->setTemplateLine($tests[$e->getTestName()]);
            }

            throw $e;
        }

    }
}
