<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/contrib/localgov_base/templates/layout/page.html.twig */
class __TwigTemplate_6a5bccb392bbfeefcb3345c000e18c40 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'header' => [$this, 'block_header'],
            'footer_sections' => [$this, 'block_footer_sections'],
            'pre_footer' => [$this, 'block_pre_footer'],
            'footer' => [$this, 'block_footer'],
            'post_footer' => [$this, 'block_post_footer'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 55
        yield "
";
        // line 62
        $context["footer_regions"] = ["has_footer_first", "has_footer_second", "has_footer_third", "footer", "has_lower_footer_first", "has_lower_footer_second", "has_lower_footer_third"];
        // line 72
        yield "
";
        // line 83
        if ((($tmp = ($context["has_tabs"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 84
            yield "  ";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "tabs", [], "any", false, false, true, 84), "html", null, true);
            yield "
";
        }
        // line 86
        yield "
";
        // line 87
        yield from $this->unwrap()->yieldBlock('header', $context, $blocks);
        // line 90
        yield "
";
        // line 91
        if ((($tmp = ($context["has_banner"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 92
            yield "  ";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "banner", [], "any", false, false, true, 92), "html", null, true);
            yield "
";
        }
        // line 94
        yield "
";
        // line 95
        if ((($tmp = ($context["has_breadcrumb"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 96
            yield "  ";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "breadcrumb", [], "any", false, false, true, 96), "html", null, true);
            yield "
";
        }
        // line 98
        yield "
";
        // line 99
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "messages", [], "any", false, false, true, 99), "html", null, true);
        yield "

<main class=\"main\" id=\"main-content\" tabindex=\"-1\"> ";
        // line 102
        yield "
  ";
        // line 103
        if ((($tmp = ($context["has_content_top"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 104
            yield "    ";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "content_top", [], "any", false, false, true, 104), "html", null, true);
            yield "
  ";
        }
        // line 106
        yield "
  ";
        // line 108
        yield "  ";
        if ((($tmp = ($context["has_sidebars"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 109
            yield "    <div class=\"lgd-container\">
      <div class=\"lgd-row\">
        ";
            // line 111
            if (((($tmp = ($context["has_sidebar_first"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) &&  !(($tmp = ($context["has_sidebar_second"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 112
                yield "          <aside class=\"lgd-row__one-third sidebar sidebar--first\">
            ";
                // line 113
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_first", [], "any", false, false, true, 113), "html", null, true);
                yield "
          </aside>
          <div class=\"lgd-row__two-thirds\">
            <div class=\"padding-horizontal\">
              ";
                // line 117
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "content", [], "any", false, false, true, 117), "html", null, true);
                yield "
            </div>
          </div>
        ";
            }
            // line 121
            yield "
        ";
            // line 122
            if (((($tmp = ($context["has_sidebar_second"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) &&  !(($tmp = ($context["has_sidebar_first"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 123
                yield "          <div class=\"lgd-row__two-thirds\">
            <div class=\"padding-horizontal\">
              ";
                // line 125
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "content", [], "any", false, false, true, 125), "html", null, true);
                yield "
            </div>
          </div>
          <aside class=\"lgd-row__one-third sidebar sidebar--second\">
            ";
                // line 129
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_second", [], "any", false, false, true, 129), "html", null, true);
                yield "
          </aside>
        ";
            }
            // line 132
            yield "
        ";
            // line 133
            if (((($tmp = ($context["has_sidebar_first"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = ($context["has_sidebar_second"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 134
                yield "          <aside class=\"lgd-row__one-quarter sidebar sidebar--first\">
            ";
                // line 135
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_first", [], "any", false, false, true, 135), "html", null, true);
                yield "
          </aside>
          <div class=\"lgd-row__one-half\">
            <div class=\"padding-horizontal\">
              ";
                // line 139
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "content", [], "any", false, false, true, 139), "html", null, true);
                yield "
            </div>
          </div>
          <aside class=\"lgd-row__one-quarter sidebar sidebar--second\">
            ";
                // line 143
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "sidebar_second", [], "any", false, false, true, 143), "html", null, true);
                yield "
          </aside>
        ";
            }
            // line 146
            yield "      </div>
    </div>

    ";
        } else {
            // line 150
            yield "    ";
            // line 151
            yield "    ";
            // line 159
            yield "    ";
            if ( !(($tmp = ($context["node"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 160
                yield "      <div class=\"lgd-container padding-horizontal\">
        ";
                // line 161
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "content", [], "any", false, false, true, 161), "html", null, true);
                yield "
      </div>
      ";
            } else {
                // line 164
                yield "        ";
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "content", [], "any", false, false, true, 164), "html", null, true);
                yield "
    ";
            }
            // line 166
            yield "  ";
        }
        // line 167
        yield "  ";
        // line 168
        yield "
  ";
        // line 169
        if ((($tmp = ($context["has_content_bottom"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 170
            yield "    ";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "content_bottom", [], "any", false, false, true, 170), "html", null, true);
            yield "
  ";
        }
        // line 172
        yield "</main>

";
        // line 174
        if ((($tmp = ($context["back_to_top"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 175
            yield "  ";
            // line 180
            yield "  ";
            yield from $this->load("@localgov_base/_components/back-to-top.twig", 180)->unwrap()->yield($context);
        }
        // line 182
        yield "
";
        // line 184
        yield from $this->unwrap()->yieldBlock('footer_sections', $context, $blocks);
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["has_tabs", "page", "has_banner", "has_breadcrumb", "has_content_top", "has_sidebars", "has_sidebar_first", "has_sidebar_second", "node", "has_content_bottom", "back_to_top", "has_housekeeping", "has_footer_first", "has_footer_second", "has_footer_third", "has_footer", "has_lower_footer_first", "has_lower_footer_second", "has_lower_footer_third"]);        yield from [];
    }

    // line 87
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 88
        yield "  ";
        yield from $this->load("@localgov_base/layout/header.html.twig", 88)->unwrap()->yield(CoreExtension::merge($context, ["page" => ($context["page"] ?? null)]));
        yield from [];
    }

    // line 184
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_footer_sections(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 185
        yield "  ";
        if ((($tmp = ($context["footer_regions"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 186
            yield "    ";
            // line 192
            yield "    <footer class=\"lgd-footer\">

    ";
            // line 195
            yield "    ";
            yield from $this->unwrap()->yieldBlock('pre_footer', $context, $blocks);
            // line 222
            yield "    ";
            // line 223
            yield "
    ";
            // line 225
            yield "    ";
            yield from $this->unwrap()->yieldBlock('footer', $context, $blocks);
            // line 238
            yield "    ";
            // line 239
            yield "
    ";
            // line 241
            yield "    ";
            yield from $this->unwrap()->yieldBlock('post_footer', $context, $blocks);
            // line 268
            yield "    ";
            // line 269
            yield "
    ";
            // line 270
            if ((($tmp = ($context["has_housekeeping"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 271
                yield "      <div class=\"lgd-footer__housekeeping\">
      ";
                // line 272
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "housekeeping", [], "any", false, false, true, 272), "html", null, true);
                yield "
      </div>
    ";
            }
            // line 275
            yield "
    </footer>
  ";
        }
        yield from [];
    }

    // line 195
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_pre_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 196
        yield "      ";
        if ((((($tmp = ($context["has_footer_first"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($tmp = ($context["has_footer_second"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) || (($tmp = ($context["has_footer_third"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 197
            yield "        <div class=\"lgd-footer__pre-footer\">
          <div class=\"lgd-container\">
            <div class=\"lgd-row\">
              ";
            // line 200
            if ((($tmp = ($context["has_footer_first"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 201
                yield "                <div class=\"lgd-row__one-third\">
                  ";
                // line 202
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_first", [], "any", false, false, true, 202), "html", null, true);
                yield "
                </div>
              ";
            }
            // line 205
            yield "
              ";
            // line 206
            if ((($tmp = ($context["has_footer_second"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 207
                yield "                <div class=\"lgd-row__one-third\">
                  ";
                // line 208
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_second", [], "any", false, false, true, 208), "html", null, true);
                yield "
                </div>
              ";
            }
            // line 211
            yield "
              ";
            // line 212
            if ((($tmp = ($context["has_footer_third"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 213
                yield "                <div class=\"lgd-row__one-third\">
                  ";
                // line 214
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_third", [], "any", false, false, true, 214), "html", null, true);
                yield "
                </div>
              ";
            }
            // line 217
            yield "            </div>
          </div>
        </div>
      ";
        }
        // line 221
        yield "    ";
        yield from [];
    }

    // line 225
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 226
        yield "      ";
        if ((($tmp = ($context["has_footer"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 227
            yield "        <div class=\"lgd-footer__footer\">
          <div class=\"lgd-container\">
            <div class=\"lgd-row\">
              <div class=\"lgd-row__full\">
                ";
            // line 231
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer", [], "any", false, false, true, 231), "html", null, true);
            yield "
              </div>
            </div>
          </div>
        </div>
      ";
        }
        // line 237
        yield "    ";
        yield from [];
    }

    // line 241
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_post_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 242
        yield "      ";
        if ((((($tmp = ($context["has_lower_footer_first"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($tmp = ($context["has_lower_footer_second"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) || (($tmp = ($context["has_lower_footer_third"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 243
            yield "        <div class=\"lgd-footer__post-footer\">
          <div class=\"lgd-container\">
            <div class=\"lgd-row\">
              ";
            // line 246
            if ((($tmp = ($context["has_lower_footer_first"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 247
                yield "                <div class=\"lgd-row__one-third\">
                  ";
                // line 248
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "lower_footer_first", [], "any", false, false, true, 248), "html", null, true);
                yield "
                </div>
              ";
            }
            // line 251
            yield "
              ";
            // line 252
            if ((($tmp = ($context["has_lower_footer_second"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 253
                yield "                <div class=\"lgd-row__one-third\">
                  ";
                // line 254
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "lower_footer_second", [], "any", false, false, true, 254), "html", null, true);
                yield "
                </div>
              ";
            }
            // line 257
            yield "
              ";
            // line 258
            if ((($tmp = ($context["has_lower_footer_third"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 259
                yield "                <div class=\"lgd-row__one-third\">
                  ";
                // line 260
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "lower_footer_third", [], "any", false, false, true, 260), "html", null, true);
                yield "
                </div>
              ";
            }
            // line 263
            yield "            </div>
          </div>
        </div>
      ";
        }
        // line 267
        yield "    ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/contrib/localgov_base/templates/layout/page.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  482 => 267,  476 => 263,  470 => 260,  467 => 259,  465 => 258,  462 => 257,  456 => 254,  453 => 253,  451 => 252,  448 => 251,  442 => 248,  439 => 247,  437 => 246,  432 => 243,  429 => 242,  422 => 241,  417 => 237,  408 => 231,  402 => 227,  399 => 226,  392 => 225,  387 => 221,  381 => 217,  375 => 214,  372 => 213,  370 => 212,  367 => 211,  361 => 208,  358 => 207,  356 => 206,  353 => 205,  347 => 202,  344 => 201,  342 => 200,  337 => 197,  334 => 196,  327 => 195,  319 => 275,  313 => 272,  310 => 271,  308 => 270,  305 => 269,  303 => 268,  300 => 241,  297 => 239,  295 => 238,  292 => 225,  289 => 223,  287 => 222,  284 => 195,  280 => 192,  278 => 186,  275 => 185,  268 => 184,  262 => 88,  255 => 87,  249 => 184,  246 => 182,  242 => 180,  240 => 175,  238 => 174,  234 => 172,  228 => 170,  226 => 169,  223 => 168,  221 => 167,  218 => 166,  212 => 164,  206 => 161,  203 => 160,  200 => 159,  198 => 151,  196 => 150,  190 => 146,  184 => 143,  177 => 139,  170 => 135,  167 => 134,  165 => 133,  162 => 132,  156 => 129,  149 => 125,  145 => 123,  143 => 122,  140 => 121,  133 => 117,  126 => 113,  123 => 112,  121 => 111,  117 => 109,  114 => 108,  111 => 106,  105 => 104,  103 => 103,  100 => 102,  95 => 99,  92 => 98,  86 => 96,  84 => 95,  81 => 94,  75 => 92,  73 => 91,  70 => 90,  68 => 87,  65 => 86,  59 => 84,  57 => 83,  54 => 72,  52 => 62,  49 => 55,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "themes/contrib/localgov_base/templates/layout/page.html.twig", "/Users/harshtrivedi/LocalGov Drupal SCC/ssaspb/web/themes/contrib/localgov_base/templates/layout/page.html.twig");
    }
    
    public function ensureSecurityChecked(): void
    {
        if ($this->sandbox->isSandboxed($this->source)) {
            $this->checkSecurity();
        }
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 62, "if" => 83, "block" => 87, "include" => 180];
        static $filters = ["escape" => 84];
        static $functions = [];
        static $tests = [];

        try {
            $this->sandbox->checkSecurity(
                [0 => "set", 1 => "if", 2 => "block", 3 => "include"],
                [0 => "escape"],
                [],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            } elseif ($e instanceof SecurityNotAllowedTestError && isset($tests[$e->getTestName()])) {
                $e->setTemplateLine($tests[$e->getTestName()]);
            }

            throw $e;
        }

    }
}
