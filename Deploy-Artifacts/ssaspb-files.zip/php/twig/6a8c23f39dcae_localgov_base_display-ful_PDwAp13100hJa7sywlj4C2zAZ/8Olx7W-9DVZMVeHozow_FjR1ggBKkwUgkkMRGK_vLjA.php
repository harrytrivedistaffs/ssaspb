<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* localgov_base:display-full */
class __TwigTemplate_0be6013635d62a82854bac6d9b06db8b extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("core/components.localgov_base--display-full"));
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->addAdditionalContext($context, "localgov_base:display-full"));
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->validateProps($context, "localgov_base:display-full"));
        // line 5
        yield "
";
        // line 6
        if ( !(($tmp = ($context["localgov_base_remove_css"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 7
            yield "  ";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("localgov_base/full"), "html", null, true);
            yield "
  ";
            // line 8
            if ((((($context["content_type"] ?? null) == "localgov_directories_venue") || (            // line 9
($context["content_type"] ?? null) == "localgov_directories_page")) || (            // line 10
($context["content_type"] ?? null) == "localgov_directory"))) {
                // line 11
                yield "    ";
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("localgov_base/directories"), "html", null, true);
                yield "
  ";
            }
            // line 13
            yield "
  ";
            // line 14
            if (((($context["content_type"] ?? null) == "localgov_step_by_step_overview") || (            // line 15
($context["content_type"] ?? null) == "localgov_step_by_step_page"))) {
                // line 16
                yield "    ";
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("localgov_base/step-by-step"), "html", null, true);
                yield "
  ";
            }
        }
        // line 19
        yield "
";
        // line 21
        $context["classes"] = [\Drupal\Component\Utility\Html::getClass(        // line 22
($context["content_type"] ?? null)), "node", (((($tmp =         // line 24
($context["restricted_width_content_type"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("node--with-restricted-width") : ("")), (((($tmp =         // line 25
($context["display_full_promoted"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("node--promoted") : ("")), (((($tmp =         // line 26
($context["display_full_sticky"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("node--sticky") : ("")), (((($tmp =         // line 27
($context["display_full_unpublished"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("node--unpublished") : ("")), (((($tmp =         // line 28
($context["view_mode"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (("node--view-mode-" . \Drupal\Component\Utility\Html::getClass(($context["view_mode"] ?? null)))) : ("")), ("node--type-" . \Drupal\Component\Utility\Html::getClass(        // line 29
($context["content_type"] ?? null)))];
        // line 32
        yield "
<article";
        // line 33
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [($context["classes"] ?? null)], "method", false, false, true, 33), "removeAttribute", ["role"], "method", false, false, true, 33), "html", null, true);
        yield ">

  <div class=\"lgd-container padding-horizontal\">
    ";
        // line 36
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["title_prefix"] ?? null), "html", null, true);
        yield "
    ";
        // line 37
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["title_suffix"] ?? null), "html", null, true);
        yield "

    ";
        // line 39
        if ((($tmp = ($context["display_submitted"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 40
            yield "      <footer class=\"node__meta\">
        ";
            // line 41
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["author_picture"] ?? null), "html", null, true);
            yield "
        <div";
            // line 42
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["author_attributes"] ?? null), "addClass", ["node__submitted"], "method", false, false, true, 42), "html", null, true);
            yield ">
          ";
            // line 43
            yield t("Submitted by @author_name on @date", ["@author_name" => $this->env->getExtension(\Drupal\Core\Template\TwigExtension::class)->renderVar(($context["author_name"] ?? null)), "@date" => $this->env->getExtension(\Drupal\Core\Template\TwigExtension::class)->renderVar(($context["date"] ?? null)), ]);
            // line 44
            yield "          ";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["metadata"] ?? null), "html", null, true);
            yield "
        </div>
      </footer>
    ";
        }
        // line 48
        yield "
    ";
        // line 49
        if (CoreExtension::inFilter(($context["content_type"] ?? null), ($context["restricted_width_content_types"] ?? null))) {
            // line 50
            yield "      <div class=\"node__restricted-width-section\">
    ";
        }
        // line 52
        yield "
      <div";
        // line 53
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["content_attributes"] ?? null), "addClass", [(\Drupal\Component\Utility\Html::getClass(($context["content_type"] ?? null)) . "__content"), "node__content"], "method", false, false, true, 53), "html", null, true);
        yield ">
        ";
        // line 54
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["display_full_content"] ?? null), "html", null, true);
        yield "
      </div>
  </div>

  ";
        // line 58
        if ((($tmp = ($context["localgov_subsites_content"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 59
            yield "    ";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["localgov_subsites_content"] ?? null), "html", null, true);
            yield "
  ";
        }
        // line 61
        yield "

  ";
        // line 63
        if (CoreExtension::inFilter(($context["content_type"] ?? null), ($context["restricted_width_content_types"] ?? null))) {
            // line 64
            yield "    </div>
  ";
        }
        // line 66
        yield "
</article>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["localgov_base_remove_css", "content_type", "restricted_width_content_type", "display_full_promoted", "display_full_sticky", "display_full_unpublished", "view_mode", "attributes", "title_prefix", "title_suffix", "display_submitted", "author_picture", "author_attributes", "author_name", "date", "metadata", "restricted_width_content_types", "content_attributes", "display_full_content", "localgov_subsites_content"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "localgov_base:display-full";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  175 => 66,  171 => 64,  169 => 63,  165 => 61,  159 => 59,  157 => 58,  150 => 54,  146 => 53,  143 => 52,  139 => 50,  137 => 49,  134 => 48,  126 => 44,  124 => 43,  120 => 42,  116 => 41,  113 => 40,  111 => 39,  106 => 37,  102 => 36,  96 => 33,  93 => 32,  91 => 29,  90 => 28,  89 => 27,  88 => 26,  87 => 25,  86 => 24,  85 => 22,  84 => 21,  81 => 19,  74 => 16,  72 => 15,  71 => 14,  68 => 13,  62 => 11,  60 => 10,  59 => 9,  58 => 8,  53 => 7,  51 => 6,  48 => 5,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "localgov_base:display-full", "themes/contrib/localgov_base/components/content/displays/display-full/display-full.twig");
    }
    
    public function ensureSecurityChecked(): void
    {
        if ($this->sandbox->isSandboxed($this->source)) {
            $this->checkSecurity();
        }
    }
    
    public function checkSecurity()
    {
        static $tags = ["if" => 6, "set" => 21, "trans" => 43];
        static $filters = ["escape" => 7, "clean_class" => 22];
        static $functions = ["attach_library" => 7];
        static $tests = [];

        try {
            $this->sandbox->checkSecurity(
                [0 => "if", 1 => "set", 2 => "trans"],
                [0 => "escape", 1 => "clean_class"],
                [0 => "attach_library"],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            } elseif ($e instanceof SecurityNotAllowedTestError && isset($tests[$e->getTestName()])) {
                $e->setTemplateLine($tests[$e->getTestName()]);
            }

            throw $e;
        }

    }
}
