<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/contrib/localgov_base/templates/content/node--full.html.twig */
class __TwigTemplate_e192437a35e77b97366b410e9ac32f20 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 73
        yield "
";
        // line 74
        $context["content_type"] = CoreExtension::getAttribute($this->env, $this->source, ($context["node"] ?? null), "bundle", [], "any", false, false, true, 74);
        // line 75
        yield "
";
        // line 76
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["node"] ?? null), "isPromoted", [], "method", false, false, true, 76)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 77
            yield "  ";
            $context["display_full_promoted"] = true;
        }
        // line 79
        yield "
";
        // line 80
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["node"] ?? null), "isSticky", [], "method", false, false, true, 80)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 81
            yield "  ";
            $context["display_full_sticky"] = true;
        }
        // line 83
        yield "
";
        // line 84
        if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["node"] ?? null), "isPublished", [], "method", false, false, true, 84)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 85
            yield "  ";
            $context["display_full_unpublished"] = true;
        }
        // line 87
        yield "
";
        // line 88
        $context["display_full_content"] = $this->extensions['Drupal\Core\Template\TwigExtension']->withoutFilter(($context["content"] ?? null), "localgov_subsites_content");
        // line 89
        yield "
";
        // line 90
        if (((($tmp = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["node"] ?? null), "localgov_subsites_content", [], "any", false, false, true, 90), "value", [], "any", false, false, true, 90)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || ((($_v0 = CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "localgov_subsites_content", [], "any", false, false, true, 90)) && is_array($_v0) || $_v0 instanceof ArrayAccess && in_array($_v0::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v0["#type"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "localgov_subsites_content", [], "any", false, false, true, 90), "#type", [], "array", false, false, true, 90)) == "layout_paragraphs_builder"))) {
            // line 91
            yield "  ";
            $context["localgov_subsites_content"] = CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "localgov_subsites_content", [], "any", false, false, true, 91);
        }
        // line 93
        yield "
";
        // line 94
        yield from $this->load("localgov_base:display-full", 94)->unwrap()->yield($context);
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["node", "content"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/contrib/localgov_base/templates/content/node--full.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  93 => 94,  90 => 93,  86 => 91,  84 => 90,  81 => 89,  79 => 88,  76 => 87,  72 => 85,  70 => 84,  67 => 83,  63 => 81,  61 => 80,  58 => 79,  54 => 77,  52 => 76,  49 => 75,  47 => 74,  44 => 73,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "themes/contrib/localgov_base/templates/content/node--full.html.twig", "/Users/harshtrivedi/LocalGov Drupal SCC/ssaspb/web/themes/contrib/localgov_base/templates/content/node--full.html.twig");
    }
    
    public function ensureSecurityChecked(): void
    {
        if ($this->sandbox->isSandboxed($this->source)) {
            $this->checkSecurity();
        }
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 74, "if" => 76, "include" => 94];
        static $filters = ["without" => 88];
        static $functions = [];
        static $tests = [];

        try {
            $this->sandbox->checkSecurity(
                [0 => "set", 1 => "if", 2 => "include"],
                [0 => "without"],
                [],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            } elseif ($e instanceof SecurityNotAllowedTestError && isset($tests[$e->getTestName()])) {
                $e->setTemplateLine($tests[$e->getTestName()]);
            }

            throw $e;
        }

    }
}
