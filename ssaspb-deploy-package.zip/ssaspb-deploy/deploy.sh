#!/usr/bin/env bash
#
# One-command deploy for cPanel. Run this AFTER you've:
#   1. Uploaded and extracted this whole package into your site's repo
#      folder (the one that contains this deploy.sh).
#   2. Created a MySQL database in cPanel and imported
#      database/ssaspb_database.sql.gz into it via phpMyAdmin.
#   3. Edited web/sites/default/settings.php with that database's name,
#      username and password.
#
# This script installs the Drupal codebase (core, contrib modules, the
# Splide/Blazy libraries etc — none of that ships in this package, composer
# downloads it fresh) and brings caches in line with the imported database.
#
# Usage:
#   bash deploy.sh
#
# If your cPanel account's default `php` isn't 8.3+, set PHP_BIN first
# (Software > MultiPHP Manager in cPanel shows the exact path, usually
# something like /opt/cpanel/ea-php83/root/usr/bin/php):
#   PHP_BIN=/opt/cpanel/ea-php83/root/usr/bin/php bash deploy.sh

set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"

if [ ! -f composer.json ]; then
  echo "deploy.sh: composer.json not found here, run this from the package root." >&2
  exit 1
fi

PHP_BIN="${PHP_BIN:-php}"
if [ "$PHP_BIN" != "php" ]; then
  export PATH
  PATH="$(dirname "$PHP_BIN"):$PATH"
fi

PHP_VERSION="$("$PHP_BIN" -r 'echo PHP_VERSION;')"
echo "==> Using PHP $PHP_VERSION ($PHP_BIN)"
case "$PHP_VERSION" in
  8.3.*|8.4.*) ;;
  *)
    echo "    Warning: Drupal 11 wants PHP 8.3 or 8.4, this looks off."
    echo "    Re-run as: PHP_BIN=/path/to/php8.3 bash deploy.sh"
    ;;
esac

if grep -q "REPLACE_WITH_DB_NAME" web/sites/default/settings.php 2>/dev/null; then
  echo "deploy.sh: web/sites/default/settings.php still has the placeholder" >&2
  echo "database credentials in it. Edit that file with your real cPanel" >&2
  echo "MySQL database name/username/password first, then re-run this script." >&2
  exit 1
fi

mkdir -p web/sites/default/files

echo
if command -v composer >/dev/null 2>&1; then
  echo "==> composer install"
  composer install --no-dev --optimize-autoloader
else
  echo "==> composer not found on PATH, downloading composer.phar locally instead"
  if [ ! -f composer.phar ]; then
    if command -v curl >/dev/null 2>&1; then
      curl -fsSL -o composer.phar https://getcomposer.org/composer-stable.phar
    elif command -v wget >/dev/null 2>&1; then
      wget -q -O composer.phar https://getcomposer.org/composer-stable.phar
    else
      echo "deploy.sh: neither curl nor wget is available to download composer.phar." >&2
      echo "Download it yourself and place it at $(pwd)/composer.phar:" >&2
      echo "  https://getcomposer.org/composer-stable.phar" >&2
      exit 1
    fi
    if [ ! -s composer.phar ]; then
      echo "deploy.sh: composer.phar download failed (empty or missing file)." >&2
      rm -f composer.phar
      exit 1
    fi
    chmod +x composer.phar
  fi
  echo "==> composer install"
  "$PHP_BIN" composer.phar install --no-dev --optimize-autoloader
fi

echo
echo "==> drush cache rebuild"
vendor/bin/drush cr -y

echo
echo "==> Done. Visit your site and log in with the admin credentials from README.md."
