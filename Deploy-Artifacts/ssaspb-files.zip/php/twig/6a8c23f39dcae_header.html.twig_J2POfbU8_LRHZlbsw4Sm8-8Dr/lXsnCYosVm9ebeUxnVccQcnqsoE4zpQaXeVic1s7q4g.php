<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @localgov_base/layout/header.html.twig */
class __TwigTemplate_b613b6b104da42b6a0c88054ab45ce3b extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        if ( !(($tmp = ($context["localgov_base_remove_js"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 3
            yield "  ";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("localgov_base/header-js"), "html", null, true);
            yield "
";
        }
        // line 5
        yield "
<header class=\"lgd-header\">
  <div class=\"lgd-container\">
    <div class=\"lgd-row\">
      <div class=\"lgd-row__full\">
        <div class=\"lgd-header__inner\">

          ";
        // line 12
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "header", [], "any", false, false, true, 12), "html", null, true);
        yield "

          ";
        // line 14
        if ((((($tmp = ($context["has_primary_menu"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($tmp = ($context["has_search"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) || (($tmp = ($context["has_secondary_menu"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 15
            yield "            ";
            // line 21
            yield "            <div class=\"lgd-header__toggles\">
              ";
            // line 22
            if ((($tmp = ($context["has_secondary_menu"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 23
                yield "                <button
                  class=\"lgd-header__toggle lgd-header__toggle--secondary\"
                  data-target=\"lgd-header__nav--secondary\"
                  aria-controls=\"lgd-header__nav--secondary\"
                  aria-expanded=\"false\"
                  aria-label=\"";
                // line 28
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Services: jump to services"));
                yield "\"
                >
                  <span class=\"lgd-header__toggle-text lgd-header__toggle-text--secondary\">";
                // line 30
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Services"));
                yield "</span>
                  <span class=\"lgd-header__toggle-icon lgd-header__toggle-icon--secondary\"></span>
                </button>
              ";
            }
            // line 34
            yield "
              ";
            // line 35
            if (((($tmp = ($context["has_primary_menu"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($tmp = ($context["has_search"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 36
                yield "                <button
                  class=\"lgd-header__toggle lgd-header__toggle--primary\"
                  data-target=\"lgd-header__nav--primary\"
                  aria-controls=\"lgd-header__nav--primary\"
                  aria-expanded=\"false\"
                >
                  <span class=\"lgd-header__toggle-text lgd-header__toggle-text--primary\">";
                // line 42
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Menu"));
                yield "</span>
                  <span class=\"lgd-header__toggle-icon lgd-header__toggle-icon--primary\"></span>
                </button>
              ";
            }
            // line 46
            yield "            </div>

            ";
            // line 48
            if (((($tmp = ($context["has_primary_menu"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($tmp = ($context["has_search"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 49
                yield "              <div id=\"lgd-header__nav--primary\" class=\"lgd-header__nav lgd-header__nav--primary\">
                ";
                // line 50
                if ((($tmp = ($context["has_primary_menu"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 51
                    yield "                  ";
                    yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "primary_menu", [], "any", false, false, true, 51), "html", null, true);
                    yield "
                ";
                }
                // line 53
                yield "
                ";
                // line 54
                if ((($tmp = ($context["has_search"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 55
                    yield "                  ";
                    yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "search", [], "any", false, false, true, 55), "html", null, true);
                    yield "
                ";
                }
                // line 57
                yield "              </div>
            ";
            }
            // line 59
            yield "
          ";
        }
        // line 61
        yield "
          ";
        // line 62
        if ((($tmp = ($context["has_secondary_menu"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 63
            yield "            <div id=\"lgd-header__nav--secondary\" class=\"lgd-header__nav lgd-header__nav--secondary\">
              ";
            // line 64
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "secondary_menu", [], "any", false, false, true, 64), "html", null, true);
            yield "
            </div>
          ";
        }
        // line 67
        yield "
        </div>
      </div>
    </div>
  </div>
  ";
        // line 72
        if ((($tmp = ($context["has_subsites_menu"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 73
            yield "    <div id=\"lgd-header__nav--subsites-menu\" class=\"lgd-header__nav lgd-header__nav--subsites-menu\">
      ";
            // line 74
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "subsites_menu", [], "any", false, false, true, 74), "html", null, true);
            yield "
    </div>
  ";
        }
        // line 77
        yield "</header>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["localgov_base_remove_js", "page", "has_primary_menu", "has_search", "has_secondary_menu", "has_subsites_menu"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@localgov_base/layout/header.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  182 => 77,  176 => 74,  173 => 73,  171 => 72,  164 => 67,  158 => 64,  155 => 63,  153 => 62,  150 => 61,  146 => 59,  142 => 57,  136 => 55,  134 => 54,  131 => 53,  125 => 51,  123 => 50,  120 => 49,  118 => 48,  114 => 46,  107 => 42,  99 => 36,  97 => 35,  94 => 34,  87 => 30,  82 => 28,  75 => 23,  73 => 22,  70 => 21,  68 => 15,  66 => 14,  61 => 12,  52 => 5,  46 => 3,  44 => 2,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@localgov_base/layout/header.html.twig", "/Users/harshtrivedi/LocalGov Drupal SCC/ssaspb/web/themes/contrib/localgov_base/templates/layout/header.html.twig");
    }
    
    public function ensureSecurityChecked(): void
    {
        if ($this->sandbox->isSandboxed($this->source)) {
            $this->checkSecurity();
        }
    }
    
    public function checkSecurity()
    {
        static $tags = ["if" => 2];
        static $filters = ["escape" => 3, "t" => 28];
        static $functions = ["attach_library" => 3];
        static $tests = [];

        try {
            $this->sandbox->checkSecurity(
                [0 => "if"],
                [0 => "escape", 1 => "t"],
                [0 => "attach_library"],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            } elseif ($e instanceof SecurityNotAllowedTestError && isset($tests[$e->getTestName()])) {
                $e->setTemplateLine($tests[$e->getTestName()]);
            }

            throw $e;
        }

    }
}
