<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/contrib/localgov_base/templates/layout/region.html.twig */
class __TwigTemplate_8bfc7464143602e49c0e0ae33702c4a3 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 16
        $context["classes"] = ["lgd-region", ("lgd-region--" . \Drupal\Component\Utility\Html::getClass(        // line 18
($context["region"] ?? null))), "region", ("region-" . \Drupal\Component\Utility\Html::getClass(        // line 20
($context["region"] ?? null)))];
        // line 23
        yield "
";
        // line 30
        if ( !(($tmp = ($context["localgov_base_remove_css"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 31
            yield "  ";
            if ((($context["region"] ?? null) == "tabs")) {
                // line 32
                yield "    ";
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("localgov_base/region-tabs"), "html", null, true);
                yield "
  ";
            }
            // line 34
            yield "
  ";
            // line 35
            if ((($context["region"] ?? null) == "subsites_menu")) {
                // line 36
                yield "    ";
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("localgov_base/subsites-menu"), "html", null, true);
                yield "
  ";
            }
            // line 38
            yield "
  ";
            // line 39
            if (((($context["region"] ?? null) == "sidebar_first") || (($context["region"] ?? null) == "sidebar_second"))) {
                // line 40
                yield "    ";
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("localgov_base/sidebar"), "html", null, true);
                yield "
  ";
            }
        }
        // line 43
        yield "
";
        // line 58
        $context["full_width_regions"] = ["banner", "header", "primary_menu", "secondary_menu", "search", "sidebar_first", "sidebar_second", "content"];
        // line 69
        yield "
";
        // line 70
        if ((($tmp = ($context["content"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 71
            yield "  <div";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [($context["classes"] ?? null)], "method", false, false, true, 71), "html", null, true);
            yield ">

    ";
            // line 73
            if (!CoreExtension::inFilter(($context["region"] ?? null), ($context["full_width_regions"] ?? null))) {
                // line 74
                yield "      <div class=\"lgd-container padding-horizontal\">
    ";
            }
            // line 76
            yield "
    <div class=\"lgd-region__inner lgd-region__inner--";
            // line 77
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, \Drupal\Component\Utility\Html::getClass(($context["region"] ?? null)), "html", null, true);
            yield "\">
      ";
            // line 78
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["content"] ?? null), "html", null, true);
            yield "
    </div>

    ";
            // line 81
            if (!CoreExtension::inFilter(($context["region"] ?? null), ($context["full_width_regions"] ?? null))) {
                // line 82
                yield "      </div>
    ";
            }
            // line 84
            yield "
  </div>
";
        }
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["region", "localgov_base_remove_css", "content", "attributes"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/contrib/localgov_base/templates/layout/region.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  126 => 84,  122 => 82,  120 => 81,  114 => 78,  110 => 77,  107 => 76,  103 => 74,  101 => 73,  95 => 71,  93 => 70,  90 => 69,  88 => 58,  85 => 43,  78 => 40,  76 => 39,  73 => 38,  67 => 36,  65 => 35,  62 => 34,  56 => 32,  53 => 31,  51 => 30,  48 => 23,  46 => 20,  45 => 18,  44 => 16,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "themes/contrib/localgov_base/templates/layout/region.html.twig", "/Users/harshtrivedi/LocalGov Drupal SCC/ssaspb/web/themes/contrib/localgov_base/templates/layout/region.html.twig");
    }
    
    public function ensureSecurityChecked(): void
    {
        if ($this->sandbox->isSandboxed($this->source)) {
            $this->checkSecurity();
        }
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 16, "if" => 30];
        static $filters = ["clean_class" => 18, "escape" => 32];
        static $functions = ["attach_library" => 32];
        static $tests = [];

        try {
            $this->sandbox->checkSecurity(
                [0 => "set", 1 => "if"],
                [0 => "clean_class", 1 => "escape"],
                [0 => "attach_library"],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            } elseif ($e instanceof SecurityNotAllowedTestError && isset($tests[$e->getTestName()])) {
                $e->setTemplateLine($tests[$e->getTestName()]);
            }

            throw $e;
        }

    }
}
