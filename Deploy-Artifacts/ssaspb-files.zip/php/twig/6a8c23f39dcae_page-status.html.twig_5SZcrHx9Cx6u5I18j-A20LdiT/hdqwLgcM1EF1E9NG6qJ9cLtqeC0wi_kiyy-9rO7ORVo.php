<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @localgov_base/layout/status-pages/page-status.html.twig */
class __TwigTemplate_92fdced3ecf3213d35007231e44e6fea extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'header' => [$this, 'block_header'],
            'page_content' => [$this, 'block_page_content'],
            'footer_sections' => [$this, 'block_footer_sections'],
            'pre_footer' => [$this, 'block_pre_footer'],
            'footer' => [$this, 'block_footer'],
            'post_footer' => [$this, 'block_post_footer'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 55
        yield "
";
        // line 62
        $context["footer_regions"] = ["has_footer_first", "has_footer_second", "has_footer_third", "footer", "has_lower_footer_first", "has_lower_footer_second", "has_lower_footer_third"];
        // line 72
        yield "
";
        // line 83
        if ((($tmp = ($context["has_tabs"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 84
            yield "  ";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "tabs", [], "any", false, false, true, 84), "html", null, true);
            yield "
";
        }
        // line 86
        yield "
";
        // line 87
        yield from $this->unwrap()->yieldBlock('header', $context, $blocks);
        // line 90
        yield "
";
        // line 91
        if ((($tmp = ($context["has_banner"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 92
            yield "  ";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "banner", [], "any", false, false, true, 92), "html", null, true);
            yield "
";
        }
        // line 94
        yield "
";
        // line 95
        if ((($tmp = ($context["has_breadcrumb"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 96
            yield "  ";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "breadcrumb", [], "any", false, false, true, 96), "html", null, true);
            yield "
";
        }
        // line 98
        yield "
";
        // line 99
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "messages", [], "any", false, false, true, 99), "html", null, true);
        yield "

<main class=\"main\" id=\"main-content\"> ";
        // line 102
        yield "
  ";
        // line 103
        if ((($tmp = ($context["has_content_top"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 104
            yield "    ";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "content_top", [], "any", false, false, true, 104), "html", null, true);
            yield "
  ";
        }
        // line 106
        yield "
  ";
        // line 107
        yield from $this->unwrap()->yieldBlock('page_content', $context, $blocks);
        // line 123
        yield "
  ";
        // line 124
        if ((($tmp = ($context["has_content_bottom"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 125
            yield "    ";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "content_bottom", [], "any", false, false, true, 125), "html", null, true);
            yield "
  ";
        }
        // line 127
        yield "</main>

";
        // line 130
        yield from $this->unwrap()->yieldBlock('footer_sections', $context, $blocks);
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["has_tabs", "page", "has_banner", "has_breadcrumb", "has_content_top", "has_content_bottom", "default_status_content", "has_footer_first", "has_footer_second", "has_footer_third", "has_footer", "has_lower_footer_first", "has_lower_footer_second", "has_lower_footer_third"]);        yield from [];
    }

    // line 87
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 88
        yield "  ";
        yield from $this->load("@localgov_base/layout/header.html.twig", 88)->unwrap()->yield(CoreExtension::merge($context, ["page" => ($context["page"] ?? null)]));
        yield from [];
    }

    // line 107
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 108
        yield "    ";
        // line 112
        yield "    <div class=\"lgd-container\">
        <div class=\"lgd-row\">
          <div class=\"lgd-row__full\">
            <div class=\"padding-horizontal\">
              ";
        // line 116
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["default_status_content"] ?? null), "html", null, true);
        yield "
              ";
        // line 117
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "content", [], "any", false, false, true, 117), "html", null, true);
        yield "
            </div>
          </div>
        </div>
    </div>
  ";
        yield from [];
    }

    // line 130
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_footer_sections(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 131
        yield "  ";
        if ((($tmp = ($context["footer_regions"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 132
            yield "    ";
            // line 138
            yield "    <footer class=\"lgd-footer\">

    ";
            // line 141
            yield "    ";
            yield from $this->unwrap()->yieldBlock('pre_footer', $context, $blocks);
            // line 168
            yield "    ";
            // line 169
            yield "
    ";
            // line 171
            yield "    ";
            yield from $this->unwrap()->yieldBlock('footer', $context, $blocks);
            // line 184
            yield "    ";
            // line 185
            yield "
    ";
            // line 187
            yield "    ";
            yield from $this->unwrap()->yieldBlock('post_footer', $context, $blocks);
            // line 214
            yield "    ";
            // line 215
            yield "
    </footer>
  ";
        }
        yield from [];
    }

    // line 141
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_pre_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 142
        yield "      ";
        if ((((($tmp = ($context["has_footer_first"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($tmp = ($context["has_footer_second"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) || (($tmp = ($context["has_footer_third"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 143
            yield "        <div class=\"lgd-footer__pre-footer\">
          <div class=\"lgd-container\">
            <div class=\"lgd-row\">
              ";
            // line 146
            if ((($tmp = ($context["has_footer_first"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 147
                yield "                <div class=\"lgd-row__one-third\">
                  ";
                // line 148
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_first", [], "any", false, false, true, 148), "html", null, true);
                yield "
                </div>
              ";
            }
            // line 151
            yield "
              ";
            // line 152
            if ((($tmp = ($context["has_footer_second"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 153
                yield "                <div class=\"lgd-row__one-third\">
                  ";
                // line 154
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_second", [], "any", false, false, true, 154), "html", null, true);
                yield "
                </div>
              ";
            }
            // line 157
            yield "
              ";
            // line 158
            if ((($tmp = ($context["has_footer_third"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 159
                yield "                <div class=\"lgd-row__one-third\">
                  ";
                // line 160
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer_third", [], "any", false, false, true, 160), "html", null, true);
                yield "
                </div>
              ";
            }
            // line 163
            yield "            </div>
          </div>
        </div>
      ";
        }
        // line 167
        yield "    ";
        yield from [];
    }

    // line 171
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 172
        yield "      ";
        if ((($tmp = ($context["has_footer"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 173
            yield "        <div class=\"lgd-footer__footer\">
          <div class=\"lgd-container\">
            <div class=\"lgd-row\">
              <div class=\"lgd-row__full\">
                ";
            // line 177
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "footer", [], "any", false, false, true, 177), "html", null, true);
            yield "
              </div>
            </div>
          </div>
        </div>
      ";
        }
        // line 183
        yield "    ";
        yield from [];
    }

    // line 187
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_post_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 188
        yield "      ";
        if ((((($tmp = ($context["has_lower_footer_first"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($tmp = ($context["has_lower_footer_second"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) || (($tmp = ($context["has_lower_footer_third"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 189
            yield "        <div class=\"lgd-footer__post-footer\">
          <div class=\"lgd-container\">
            <div class=\"lgd-row\">
              ";
            // line 192
            if ((($tmp = ($context["has_lower_footer_first"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 193
                yield "                <div class=\"lgd-row__one-third\">
                  ";
                // line 194
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "lower_footer_first", [], "any", false, false, true, 194), "html", null, true);
                yield "
                </div>
              ";
            }
            // line 197
            yield "
              ";
            // line 198
            if ((($tmp = ($context["has_lower_footer_second"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 199
                yield "                <div class=\"lgd-row__one-third\">
                  ";
                // line 200
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "lower_footer_second", [], "any", false, false, true, 200), "html", null, true);
                yield "
                </div>
              ";
            }
            // line 203
            yield "
              ";
            // line 204
            if ((($tmp = ($context["has_lower_footer_third"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 205
                yield "                <div class=\"lgd-row__one-third\">
                  ";
                // line 206
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "lower_footer_third", [], "any", false, false, true, 206), "html", null, true);
                yield "
                </div>
              ";
            }
            // line 209
            yield "            </div>
          </div>
        </div>
      ";
        }
        // line 213
        yield "    ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@localgov_base/layout/status-pages/page-status.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  381 => 213,  375 => 209,  369 => 206,  366 => 205,  364 => 204,  361 => 203,  355 => 200,  352 => 199,  350 => 198,  347 => 197,  341 => 194,  338 => 193,  336 => 192,  331 => 189,  328 => 188,  321 => 187,  316 => 183,  307 => 177,  301 => 173,  298 => 172,  291 => 171,  286 => 167,  280 => 163,  274 => 160,  271 => 159,  269 => 158,  266 => 157,  260 => 154,  257 => 153,  255 => 152,  252 => 151,  246 => 148,  243 => 147,  241 => 146,  236 => 143,  233 => 142,  226 => 141,  218 => 215,  216 => 214,  213 => 187,  210 => 185,  208 => 184,  205 => 171,  202 => 169,  200 => 168,  197 => 141,  193 => 138,  191 => 132,  188 => 131,  181 => 130,  170 => 117,  166 => 116,  160 => 112,  158 => 108,  151 => 107,  145 => 88,  138 => 87,  132 => 130,  128 => 127,  122 => 125,  120 => 124,  117 => 123,  115 => 107,  112 => 106,  106 => 104,  104 => 103,  101 => 102,  96 => 99,  93 => 98,  87 => 96,  85 => 95,  82 => 94,  76 => 92,  74 => 91,  71 => 90,  69 => 87,  66 => 86,  60 => 84,  58 => 83,  55 => 72,  53 => 62,  50 => 55,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@localgov_base/layout/status-pages/page-status.html.twig", "/Users/harshtrivedi/LocalGov Drupal SCC/ssaspb/web/themes/contrib/localgov_base/templates/layout/status-pages/page-status.html.twig");
    }
    
    public function ensureSecurityChecked(): void
    {
        if ($this->sandbox->isSandboxed($this->source)) {
            $this->checkSecurity();
        }
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 62, "if" => 83, "block" => 87, "include" => 88];
        static $filters = ["escape" => 84];
        static $functions = [];
        static $tests = [];

        try {
            $this->sandbox->checkSecurity(
                [0 => "set", 1 => "if", 2 => "block", 3 => "include"],
                [0 => "escape"],
                [],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            } elseif ($e instanceof SecurityNotAllowedTestError && isset($tests[$e->getTestName()])) {
                $e->setTemplateLine($tests[$e->getTestName()]);
            }

            throw $e;
        }

    }
}
