<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/contrib/localgov_base/templates/block/localgov-page-header-block.html.twig */
class __TwigTemplate_7d5ca9a7cf150fb0683955a4457a8a02 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 11
        yield "
";
        // line 12
        if ( !(($tmp = ($context["localgov_base_remove_css"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 13
            yield "  ";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("localgov_base/page-title-block"), "html", null, true);
            yield "
";
        }
        // line 15
        yield "
";
        // line 17
        $context["classes"] = ["lgd-page-title-block"];
        // line 21
        yield "
";
        // line 22
        if (((($tmp = ($context["title"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($tmp = (($_v0 = ($context["lede"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess && in_array($_v0::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v0["#value"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["lede"] ?? null), "#value", [], "array", false, false, true, 22))) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 23
            yield "  <div";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [($context["classes"] ?? null)], "method", false, false, true, 23), "html", null, true);
            yield ">

    ";
            // line 25
            if ((($tmp = ($context["title"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 26
                yield "      <h1 class=\"lgd-page-title-block__title\">
        ";
                // line 27
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["title"] ?? null), "html", null, true);
                yield "
        ";
                // line 28
                if ((($tmp = ($context["subtitle"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 29
                    yield "          <div class=\"lgd-page-title-block__subtitle\">";
                    yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["subtitle"] ?? null), "html", null, true);
                    yield "</div>
        ";
                }
                // line 31
                yield "      </h1>
    ";
            }
            // line 33
            yield "
    ";
            // line 34
            if ((($tmp = ($context["lede"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 35
                yield "      ";
                if ((($tmp = (($_v1 = ($context["lede"] ?? null)) && is_array($_v1) || $_v1 instanceof ArrayAccess && in_array($_v1::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v1["#value"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["lede"] ?? null), "#value", [], "array", false, false, true, 35))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 36
                    yield "        <p class=\"lgd-page-title-block__subheader\">";
                    yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, (($_v2 = ($context["lede"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess && in_array($_v2::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v2["#value"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["lede"] ?? null), "#value", [], "array", false, false, true, 36)), "html", null, true);
                    yield "</p>
      ";
                } else {
                    // line 38
                    yield "        ";
                    yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["lede"] ?? null), "html", null, true);
                    yield "
      ";
                }
                // line 40
                yield "    ";
            }
            // line 41
            yield "
  </div>
";
        }
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["localgov_base_remove_css", "title", "lede", "attributes", "subtitle"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/contrib/localgov_base/templates/block/localgov-page-header-block.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  115 => 41,  112 => 40,  106 => 38,  100 => 36,  97 => 35,  95 => 34,  92 => 33,  88 => 31,  82 => 29,  80 => 28,  76 => 27,  73 => 26,  71 => 25,  65 => 23,  63 => 22,  60 => 21,  58 => 17,  55 => 15,  49 => 13,  47 => 12,  44 => 11,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "themes/contrib/localgov_base/templates/block/localgov-page-header-block.html.twig", "/Users/harshtrivedi/LocalGov Drupal SCC/ssaspb/web/themes/contrib/localgov_base/templates/block/localgov-page-header-block.html.twig");
    }
    
    public function ensureSecurityChecked(): void
    {
        if ($this->sandbox->isSandboxed($this->source)) {
            $this->checkSecurity();
        }
    }
    
    public function checkSecurity()
    {
        static $tags = ["if" => 12, "set" => 17];
        static $filters = ["escape" => 13];
        static $functions = ["attach_library" => 13];
        static $tests = [];

        try {
            $this->sandbox->checkSecurity(
                [0 => "if", 1 => "set"],
                [0 => "escape"],
                [0 => "attach_library"],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            } elseif ($e instanceof SecurityNotAllowedTestError && isset($tests[$e->getTestName()])) {
                $e->setTemplateLine($tests[$e->getTestName()]);
            }

            throw $e;
        }

    }
}
