<?php

// SSASPB production settings.
//
// Fill in the four database values below with the MySQL database you
// created in cPanel (MySQL Databases), then upload the database dump from
// database/ssaspb_database.sql.gz into that same database via phpMyAdmin
// (Import tab). See README.md in this package for the full walkthrough.

$databases['default']['default'] = [
  'database' => 'REPLACE_WITH_DB_NAME',
  'username' => 'REPLACE_WITH_DB_USER',
  'password' => 'REPLACE_WITH_DB_PASSWORD',
  'prefix' => '',
  'host' => 'localhost',
  'port' => '3306',
  'isolation_level' => 'READ COMMITTED',
  'driver' => 'mysql',
  'namespace' => 'Drupal\\mysql\\Driver\\Database\\mysql',
  'autoload' => 'core/modules/mysql/src/Driver/Database/mysql/',
];

$settings['config_sync_directory'] = '../config/sync';

$settings['hash_salt'] = 'rEkR3E-NRukF5eL4KgqiawoG1q1TFb5rgCZHqCSWwpScR-Q2UxYv2dQWOl0bnLvV-PIBbxl_iQ';

// Uncomment and set this to your real domain once you know it — Drupal
// rejects requests with an unrecognised Host header otherwise.
// $settings['trusted_host_patterns'] = [
//   '^ssaspb\.staffordshire\.gov\.uk$',
// ];

$settings['file_scan_ignore_directories'] = [
  'node_modules',
  'bower_components',
];

$settings['entity_update_batch_size'] = 50;
$settings['entity_update_backup'] = TRUE;
$settings['migrate_node_migrate_type_classic'] = FALSE;

$settings['container_yamls'][] = $app_root . '/' . $site_path . '/services.yml';

if (file_exists($app_root . '/' . $site_path . '/settings.local.php')) {
  include $app_root . '/' . $site_path . '/settings.local.php';
}
