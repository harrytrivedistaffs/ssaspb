# SSASPB — deploy package

This is a snapshot of the Staffordshire and Stoke-on-Trent Adult Safeguarding
Partnership Board site, ready to deploy to a cPanel host.

## What's in here

- `composer.json` / `composer.lock` — pins the exact Drupal core, contrib
  module and library versions this site uses. `deploy.sh` uses these to
  download everything fresh (Drupal core, contrib modules, the Splide
  carousel library etc aren't included in this zip — composer fetches them).
- `web/themes/custom/ssaspb` — the custom theme (Tailwind-compiled CSS is
  already built and committed, so the server doesn't need Node.js).
- `web/modules/custom/ssaspb_seed` — the module that seeds placeholder
  content on a *fresh* install. Not used for this deploy (you're importing a
  real database instead), kept for reference/future fresh installs.
- `web/sites/default/files` — the uploaded images currently on the site
  (placeholder photos, partner logos, the site logo).
- `config/sync` — a full export of the site's configuration, kept as a
  reference/backup. Not required for this deploy (the database dump already
  contains the live config), but useful if you ever need `drush config:import`.
- `database/ssaspb_database.sql.gz` — a full dump of the working database:
  content, config, users, everything. This is the fastest path to a working
  site — import it and you have an exact copy of what's been tested.
- `deploy.sh` — installs the codebase via composer and rebuilds caches.
- `.htaccess` — redirects the domain root to `web/`, since Drupal's real
  webroot is the `web/` subdirectory, not the repo root.
- `web/sites/default/settings.php` — production settings file. **You must
  edit the database credentials in this file before running deploy.sh**
  (see Step 3 below).

## Deploy steps

### 1. Upload the code

Upload this whole folder to your cPanel account (via File Manager or FTP),
e.g. into `~/ssaspb/`. Point the domain/subdomain's document root at
`~/ssaspb/web` if your host lets you set that directly — otherwise leave it
pointed at `~/ssaspb` and the included `.htaccess` will redirect visitors
into `web/` automatically.

### 2. Create the database and import it

In cPanel:
1. **MySQL Databases** → create a new database and a new database user, add
   that user to the database with **All Privileges**. Note the database
   name, username and password — cPanel usually prefixes them with your
   account name, e.g. `youraccount_ssaspb`.
2. **phpMyAdmin** → select the new (empty) database → **Import** tab →
   choose `database/ssaspb_database.sql.gz` (phpMyAdmin decompresses `.gz`
   automatically) → Go.
   - If your host's phpMyAdmin rejects the file for being too large
     (~3.6MB compressed / ~25MB uncompressed), check **Import size limits**
     in `php.ini`/MultiPHP INI Editor in cPanel (`upload_max_filesize`,
     `post_max_size`), or ask your host to run the import for you, or use
     the SSH Terminal if your plan includes one:
     `gunzip < database/ssaspb_database.sql.gz | mysql -u DBUSER -p DBNAME`

### 3. Edit settings.php

Open `web/sites/default/settings.php` and replace the three placeholder
values with the real database name/username/password from step 2:

```php
$databases['default']['default'] = [
  'database' => 'REPLACE_WITH_DB_NAME',
  'username' => 'REPLACE_WITH_DB_USER',
  'password' => 'REPLACE_WITH_DB_PASSWORD',
  ...
```

While you're in there, uncomment and set `trusted_host_patterns` to your
real domain — Drupal will reject requests otherwise.

### 4. Run deploy.sh

Via cPanel's **Terminal** (or SSH if you have it):

```bash
cd ~/ssaspb
bash deploy.sh
```

This runs `composer install` (downloads Drupal core, contrib modules, the
Splide carousel library etc. — none of that is in this zip) and rebuilds
Drupal's caches. If your account's default `php` isn't 8.3+, see the note
at the top of `deploy.sh` for how to point it at the right PHP binary
(check **MultiPHP Manager** in cPanel for the exact path).

No SSH/Terminal on your plan? You can skip `deploy.sh` and instead run
`composer install --no-dev --optimize-autoloader` from your local machine
pointed at the uploaded folder over SFTP, or ask your host's support to run
it — either way, the codebase needs that composer install step once before
the site will load, since core/contrib aren't shipped in this zip.

### 5. Log in

Visit your domain and log in at `/user/login`:

- **Username:** `admin`
- **Password:** `Ssaspb2026!Admin`

**Change this password immediately after first login** (or right after the
database import, via `drush upwd admin "new-password"` if you have shell
access) — it's been sitting in this document, so treat it as already
public.

## What's been verified working

- Homepage, all header/footer nav links, all hero CTA buttons, all footer
  menu links (About us / Safeguarding / Resources / Contact) — every one
  resolves to a real page, no 404s.
- News listing (`/news`) and all 3 seeded news articles.
- Partner logo carousel (Splide) — autoplay, arrows, pagination, pause
  toggle all functioning.
- Admin routes (`/admin/content`, `/admin/structure/*`, node add/edit
  forms) — load correctly for an authenticated admin user; correctly
  return 403 for anonymous visitors (that's expected, not a bug).
- No PHP errors in the log at time of packaging (`drush watchdog:show`).
- Favicon set (was previously missing, causing 404s on every page load —
  fixed).
- Homepage-only hero banner — was previously showing on every page
  site-wide (a real bug, now fixed); confirmed it now only appears on the
  front page.

## What's still placeholder content

All body/summary text ("Summary 1. Replace this with...", subpage intro
text) and the diagonal-purple-stripe "PLACEHOLDER — replace this image"
images are intentional placeholders — replace them with real copy and
photography before this goes fully live. Nothing else on the frontend
should need code changes to do that; it's all real fields/content, not
hardcoded markup.
