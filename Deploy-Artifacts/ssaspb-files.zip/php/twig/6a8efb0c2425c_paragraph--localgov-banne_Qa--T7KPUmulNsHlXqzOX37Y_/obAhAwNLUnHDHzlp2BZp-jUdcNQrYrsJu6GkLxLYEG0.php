<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/ssaspb/templates/paragraphs/paragraph--localgov-banner-primary.html.twig */
class __TwigTemplate_57ca9ea9a5771a0412f7983959dc8b87 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 10
        yield "
";
        // line 12
        $context["classes"] = ["ssaspb-hero", (((        // line 14
($context["hero_theme"] ?? null) == "theme_b")) ? ("ssaspb-hero--theme-purple") : ("")), (((($tmp =         // line 15
($context["hero_image_url"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("") : ("ssaspb-hero--placeholder-bg")), "paragraph", ("paragraph--type--" . \Drupal\Component\Utility\Html::getClass(CoreExtension::getAttribute($this->env, $this->source,         // line 17
($context["paragraph"] ?? null), "bundle", [], "any", false, false, true, 17))), (((($tmp =         // line 18
($context["view_mode"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (("paragraph--view-mode--" . \Drupal\Component\Utility\Html::getClass(($context["view_mode"] ?? null)))) : ("")), (( !(($tmp = CoreExtension::getAttribute($this->env, $this->source,         // line 19
($context["paragraph"] ?? null), "isPublished", [], "method", false, false, true, 19)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("paragraph--unpublished") : (""))];
        // line 22
        yield "
<div";
        // line 23
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [($context["classes"] ?? null)], "method", false, false, true, 23), "html", null, true);
        if ((($tmp = ($context["hero_image_url"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield " style=\"background-image:url(\x27";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["hero_image_url"] ?? null), "html", null, true);
            yield "\x27)\"";
        }
        yield ">
  <div class=\"ssaspb-hero__inner\">
    ";
        // line 25
        if ((($tmp = ($context["hero_title"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "<h1>";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["hero_title"] ?? null), "html", null, true);
            yield "</h1>";
        }
        // line 26
        yield "    ";
        if ((($tmp = ($context["hero_text"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "<p>";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["hero_text"] ?? null), "html", null, true);
            yield "</p>";
        }
        // line 27
        yield "    <form class=\"ssaspb-hero__search\" action=\"/search/node\" method=\"get\">
      <label class=\"visually-hidden\" for=\"ssaspb-hero-search\">";
        // line 28
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Search this site"));
        yield "</label>
      <input id=\"ssaspb-hero-search\" type=\"text\" name=\"keys\" placeholder=\"";
        // line 29
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Search this site..."));
        yield "\">
      <button type=\"submit\" aria-label=\"";
        // line 30
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Search"));
        yield "\"><svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\"><circle cx=\"11\" cy=\"11\" r=\"7\"/><line x1=\"21\" y1=\"21\" x2=\"16.65\" y2=\"16.65\"/></svg></button>
    </form>
    ";
        // line 32
        if ((($tmp = ($context["hero_cta_url"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 33
            yield "      <a class=\"ssaspb-hero__cta\" href=\"";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["hero_cta_url"] ?? null), "html", null, true);
            yield "\">";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Find out more"));
            yield " <i class=\"fas fa-arrow-right\"></i></a>
    ";
        }
        // line 35
        yield "  </div>
</div>
<div class=\"ssaspb-hero__ctas-wrap\">
  <div class=\"ssaspb-hero__ctas\">
    <a class=\"ssaspb-pill ssaspb-pill--solid\" href=\"/i-am-worried-about-someone\">";
        // line 39
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("I am worried about someone"));
        yield " <span class=\"ssaspb-pill__icon\"><i class=\"fas fa-arrow-right\"></i></span></a>
    <a class=\"ssaspb-pill ssaspb-pill--solid\" href=\"/i-need-help\">";
        // line 40
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("I need help"));
        yield " <span class=\"ssaspb-pill__icon\"><i class=\"fas fa-arrow-right\"></i></span></a>
    <a class=\"ssaspb-pill ssaspb-pill--solid\" href=\"/information-for-professionals\">";
        // line 41
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Information for professionals"));
        yield " <span class=\"ssaspb-pill__icon\"><i class=\"fas fa-arrow-right\"></i></span></a>
  </div>
</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["hero_theme", "hero_image_url", "paragraph", "view_mode", "attributes", "hero_title", "hero_text", "hero_cta_url"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/ssaspb/templates/paragraphs/paragraph--localgov-banner-primary.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  120 => 41,  116 => 40,  112 => 39,  106 => 35,  98 => 33,  96 => 32,  91 => 30,  87 => 29,  83 => 28,  80 => 27,  73 => 26,  67 => 25,  57 => 23,  54 => 22,  52 => 19,  51 => 18,  50 => 17,  49 => 15,  48 => 14,  47 => 12,  44 => 10,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "themes/custom/ssaspb/templates/paragraphs/paragraph--localgov-banner-primary.html.twig", "/Users/harshtrivedi/LocalGov Drupal SCC/ssaspb/web/themes/custom/ssaspb/templates/paragraphs/paragraph--localgov-banner-primary.html.twig");
    }
    
    public function ensureSecurityChecked(): void
    {
        if ($this->sandbox->isSandboxed($this->source)) {
            $this->checkSecurity();
        }
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 12, "if" => 23];
        static $filters = ["clean_class" => 17, "escape" => 23, "t" => 28];
        static $functions = [];
        static $tests = [];

        try {
            $this->sandbox->checkSecurity(
                [0 => "set", 1 => "if"],
                [0 => "clean_class", 1 => "escape", 2 => "t"],
                [],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            } elseif ($e instanceof SecurityNotAllowedTestError && isset($tests[$e->getTestName()])) {
                $e->setTemplateLine($tests[$e->getTestName()]);
            }

            throw $e;
        }

    }
}
