<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/contrib/localgov_base/templates/paragraphs/paragraph--localgov-media-with-text.html.twig */
class __TwigTemplate_9332a23941c4b2785e44097adfb41803 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'paragraph' => [$this, 'block_paragraph'],
            'content' => [$this, 'block_content'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 47
        $context["classes"] = ["paragraph", ("paragraph--type--" . \Drupal\Component\Utility\Html::getClass(CoreExtension::getAttribute($this->env, $this->source,         // line 49
($context["paragraph"] ?? null), "bundle", [], "any", false, false, true, 49))), (((($tmp =         // line 50
($context["view_mode"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (("paragraph--view-mode--" . \Drupal\Component\Utility\Html::getClass(($context["view_mode"] ?? null)))) : ("")), (( !(($tmp = CoreExtension::getAttribute($this->env, $this->source,         // line 51
($context["paragraph"] ?? null), "isPublished", [], "method", false, false, true, 51)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("paragraph--unpublished") : ("")), "media-with-text", ("media-with-text--" . \Drupal\Component\Utility\Html::getClass(        // line 53
($context["style"] ?? null))), ("media-with-text--media-" . \Drupal\Component\Utility\Html::getClass(        // line 54
($context["media_position"] ?? null))), (((($tmp =         // line 55
($context["media_size"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (("media-with-text--media-" . \Drupal\Component\Utility\Html::getClass(($context["media_size"] ?? null)))) : (""))];
        // line 58
        yield "
";
        // line 59
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("localgov_base/media-with-text"), "html", null, true);
        yield "

";
        // line 61
        yield from $this->unwrap()->yieldBlock('paragraph', $context, $blocks);
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["paragraph", "view_mode", "style", "media_position", "media_size", "attributes", "content", "heading", "link"]);        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_paragraph(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 62
        yield "\t<section";
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [($context["classes"] ?? null)], "method", false, false, true, 62), "html", null, true);
        yield ">
\t\t<div class=\"media-with-text__inner\">
\t\t\t";
        // line 64
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 85
        yield "\t\t</div>
\t</section>
";
        yield from [];
    }

    // line 64
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 65
        yield "\t\t\t\t";
        if (((($context["media_position"] ?? null) == "left") || (($context["media_position"] ?? null) == "top"))) {
            // line 66
            yield "\t\t\t\t\t<div class=\"media-with-text__media\">
\t\t\t\t\t\t";
            // line 67
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "localgov_media_item", [], "any", false, false, true, 67), "html", null, true);
            yield "
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"media-with-text__body\">
\t\t\t\t\t\t";
            // line 70
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["heading"] ?? null), "html", null, true);
            yield "
\t\t\t\t\t\t";
            // line 71
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "localgov_text", [], "any", false, false, true, 71), "html", null, true);
            yield "
\t\t\t\t\t\t";
            // line 72
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["link"] ?? null), "html", null, true);
            yield "
\t\t\t\t\t</div>
\t\t\t\t";
        } else {
            // line 75
            yield "\t\t\t\t\t<div class=\"media-with-text__body\">
\t\t\t\t\t\t";
            // line 76
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["heading"] ?? null), "html", null, true);
            yield "
\t\t\t\t\t\t";
            // line 77
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "localgov_text", [], "any", false, false, true, 77), "html", null, true);
            yield "
\t\t\t\t\t\t";
            // line 78
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["link"] ?? null), "html", null, true);
            yield "
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"media-with-text__media\">
\t\t\t\t\t\t";
            // line 81
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "localgov_media_item", [], "any", false, false, true, 81), "html", null, true);
            yield "
\t\t\t\t\t</div>
\t\t\t\t";
        }
        // line 84
        yield "\t\t\t";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/contrib/localgov_base/templates/paragraphs/paragraph--localgov-media-with-text.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  145 => 84,  139 => 81,  133 => 78,  129 => 77,  125 => 76,  122 => 75,  116 => 72,  112 => 71,  108 => 70,  102 => 67,  99 => 66,  96 => 65,  89 => 64,  82 => 85,  80 => 64,  74 => 62,  62 => 61,  57 => 59,  54 => 58,  52 => 55,  51 => 54,  50 => 53,  49 => 51,  48 => 50,  47 => 49,  46 => 47,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "themes/contrib/localgov_base/templates/paragraphs/paragraph--localgov-media-with-text.html.twig", "/Users/harshtrivedi/LocalGov Drupal SCC/ssaspb/web/themes/contrib/localgov_base/templates/paragraphs/paragraph--localgov-media-with-text.html.twig");
    }
    
    public function ensureSecurityChecked(): void
    {
        if ($this->sandbox->isSandboxed($this->source)) {
            $this->checkSecurity();
        }
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 47, "block" => 61, "if" => 65];
        static $filters = ["clean_class" => 49, "escape" => 59];
        static $functions = ["attach_library" => 59];
        static $tests = [];

        try {
            $this->sandbox->checkSecurity(
                [0 => "set", 1 => "block", 2 => "if"],
                [0 => "clean_class", 1 => "escape"],
                [0 => "attach_library"],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            } elseif ($e instanceof SecurityNotAllowedTestError && isset($tests[$e->getTestName()])) {
                $e->setTemplateLine($tests[$e->getTestName()]);
            }

            throw $e;
        }

    }
}
