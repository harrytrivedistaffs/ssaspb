<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/contrib/localgov_base/templates/block/localgov-alert-banner.html.twig */
class __TwigTemplate_222382e875855c983078a6ebef48a03c extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 21
        yield "
";
        // line 22
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("localgov_alert_banner/alert_banner"), "html", null, true);
        yield "

";
        // line 24
        if ( !(($tmp = ($context["localgov_base_remove_css"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 25
            yield "  ";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("localgov_base/alert-banner"), "html", null, true);
            yield "
";
        }
        // line 27
        yield "
";
        // line 28
        $context["has_link"] =  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "link", [], "any", false, false, true, 28), 0, [], "any", false, false, true, 28));
        // line 29
        $context["type_of_alert"] = \Drupal\Component\Utility\Html::getClass((($_v0 = Twig\Extension\CoreExtension::split($this->env->getCharset(), ($context["type_of_alert"] ?? null), "--")) && is_array($_v0) || $_v0 instanceof ArrayAccess && in_array($_v0::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v0[1] ?? null) : CoreExtension::getAttribute($this->env, $this->source, Twig\Extension\CoreExtension::split($this->env->getCharset(), ($context["type_of_alert"] ?? null), "--"), 1, [], "array", false, false, true, 29)));
        // line 30
        yield "
";
        // line 31
        $context["classes"] = ["js-localgov-alert-banner", "localgov-alert-banner", (((($tmp =         // line 34
($context["type_of_alert"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (("localgov-alert-banner--" . ($context["type_of_alert"] ?? null))) : ("")), (((($tmp =         // line 35
($context["is_front"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("localgov-alert-banner--homepage") : ("")), (((($tmp =         // line 36
($context["has_link"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("localgov-alert-banner--has-link") : ("localgov-alert-banner--no-link"))];
        // line 39
        yield "
<article ";
        // line 40
        yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [($context["classes"] ?? null)], "method", false, false, true, 40), "html", null, true);
        yield ">
  ";
        // line 42
        yield "  <div class=\"lgd-container padding-horizontal\">
    ";
        // line 44
        yield "    <div class=\"localgov-alert-banner__inner\">
      ";
        // line 46
        yield "      <div class=\"localgov-alert-banner__content\">
        ";
        // line 47
        if ((($tmp = ($context["display_title"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 48
            yield "          <h2 class=\"localgov-alert-banner__title\">
            ";
            // line 49
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, (($_v1 = CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "title", [], "any", false, false, true, 49)) && is_array($_v1) || $_v1 instanceof ArrayAccess && in_array($_v1::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v1["#items"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "title", [], "any", false, false, true, 49), "#items", [], "array", false, false, true, 49)), "value", [], "any", false, false, true, 49), "html", null, true);
            yield "
          </h2>
        ";
        }
        // line 52
        yield "        
        ";
        // line 53
        if ((($tmp = (($_v2 = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "short_description", [], "any", false, false, true, 53), 0, [], "any", false, false, true, 53)) && is_array($_v2) || $_v2 instanceof ArrayAccess && in_array($_v2::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v2["#text"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "short_description", [], "any", false, false, true, 53), 0, [], "any", false, false, true, 53), "#text", [], "array", false, false, true, 53))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 54
            yield "          <div class=\"localgov-alert-banner__body\">
            ";
            // line 55
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "short_description", [], "any", false, false, true, 55), "html", null, true);
            yield "
          </div>
        ";
        }
        // line 58
        yield "
        ";
        // line 59
        if ((($tmp = ($context["has_link"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 60
            yield "          <div class=\"localgov-alert-banner--content-link\">";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["content"] ?? null), "link", [], "any", false, false, true, 60), "html", null, true);
            yield "</div>
        ";
        }
        // line 62
        yield "      </div> ";
        // line 63
        yield "
      ";
        // line 64
        if ( !(($tmp = ($context["remove_hide_link"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 65
            yield "        <div class=\"localgov-alert-banner__actions\">
          <div class=\"localgov-alert-banner__dismiss\">
            <button class=\"localgov-alert-banner__close js-localgov-alert-banner__close\" aria-label=\"";
            // line 67
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Hide alert"));
            yield "\">";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Hide"));
            yield "</button>
          </div>
        </div>
      ";
        }
        // line 71
        yield "    </div> ";
        // line 72
        yield "  </div> ";
        // line 73
        yield "</article>";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["localgov_base_remove_css", "content", "is_front", "attributes", "display_title", "remove_hide_link"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/contrib/localgov_base/templates/block/localgov-alert-banner.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  151 => 73,  149 => 72,  147 => 71,  138 => 67,  134 => 65,  132 => 64,  129 => 63,  127 => 62,  121 => 60,  119 => 59,  116 => 58,  110 => 55,  107 => 54,  105 => 53,  102 => 52,  96 => 49,  93 => 48,  91 => 47,  88 => 46,  85 => 44,  82 => 42,  78 => 40,  75 => 39,  73 => 36,  72 => 35,  71 => 34,  70 => 31,  67 => 30,  65 => 29,  63 => 28,  60 => 27,  54 => 25,  52 => 24,  47 => 22,  44 => 21,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "themes/contrib/localgov_base/templates/block/localgov-alert-banner.html.twig", "/Users/harshtrivedi/LocalGov Drupal SCC/ssaspb/web/themes/contrib/localgov_base/templates/block/localgov-alert-banner.html.twig");
    }
    
    public function ensureSecurityChecked(): void
    {
        if ($this->sandbox->isSandboxed($this->source)) {
            $this->checkSecurity();
        }
    }
    
    public function checkSecurity()
    {
        static $tags = ["if" => 24, "set" => 28];
        static $filters = ["escape" => 22, "clean_class" => 29, "split" => 29, "t" => 67];
        static $functions = ["attach_library" => 22];
        static $tests = [];

        try {
            $this->sandbox->checkSecurity(
                [0 => "if", 1 => "set"],
                [0 => "escape", 1 => "clean_class", 2 => "split", 3 => "t"],
                [0 => "attach_library"],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            } elseif ($e instanceof SecurityNotAllowedTestError && isset($tests[$e->getTestName()])) {
                $e->setTemplateLine($tests[$e->getTestName()]);
            }

            throw $e;
        }

    }
}
