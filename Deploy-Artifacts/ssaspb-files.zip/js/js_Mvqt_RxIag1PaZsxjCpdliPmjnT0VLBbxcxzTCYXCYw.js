/* @license GPL-2.0-or-later https://www.drupal.org/licensing/faq */
(($,Drupal)=>{Drupal.behaviors.layoutParagraphsComponentForm={attach:function attach(){$('[name="layout_paragraphs[layout]"]').on('change',(e)=>{$('.lpb-btn--save').prop('disabled',e.currentTarget.disabled);});$('.lpb-btn--save').prop('disabled',false);}};})(jQuery,Drupal);;
