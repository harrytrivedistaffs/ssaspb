<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/ssaspb/templates/paragraphs/paragraph--localgov-ia-block.html.twig */
class __TwigTemplate_573e92f718fd89c582e857f8f55bfa7d extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 10
        yield "
";
        // line 12
        $context["classes"] = ["ia-block", "ssaspb-resource-card", (((($tmp =         // line 15
($context["promoted"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("ia-block--promoted") : ("")), "paragraph", ("paragraph--type--" . \Drupal\Component\Utility\Html::getClass(CoreExtension::getAttribute($this->env, $this->source,         // line 17
($context["paragraph"] ?? null), "bundle", [], "any", false, false, true, 17))), (((($tmp =         // line 18
($context["view_mode"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (("paragraph--view-mode--" . \Drupal\Component\Utility\Html::getClass(($context["view_mode"] ?? null)))) : ("")), (( !(($tmp = CoreExtension::getAttribute($this->env, $this->source,         // line 19
($context["paragraph"] ?? null), "isPublished", [], "method", false, false, true, 19)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("paragraph--unpublished") : (""))];
        // line 22
        yield "
";
        // line 23
        if ( !(($tmp = ($context["localgov_base_remove_css"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 24
            yield "  ";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("localgov_base/ia-block"), "html", null, true);
            yield "
";
        }
        // line 26
        yield "
";
        // line 27
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["paragraph"] ?? null), "localgov_ia_block_title", [], "any", false, false, true, 27), "value", [], "any", false, false, true, 27)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 28
            yield "  <div";
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [($context["classes"] ?? null)], "method", false, false, true, 28), "html", null, true);
            yield ">
    <a class=\"ssaspb-resource-card__link\" href=\"";
            // line 29
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["field_link"] ?? null), "html", null, true);
            yield "\">
      <span class=\"ssaspb-resource-card__icon\" aria-hidden=\"true\"></span>
      <span class=\"ssaspb-resource-card__label\">
        ";
            // line 32
            yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["paragraph"] ?? null), "localgov_ia_block_title", [], "any", false, false, true, 32), "value", [], "any", false, false, true, 32), "html", null, true);
            yield "
        <span class=\"ssaspb-resource-card__arrow\" aria-hidden=\"true\">
          <svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\"><circle cx=\"12\" cy=\"12\" r=\"10\" /><path d=\"M10 8l4 4-4 4\" /></svg>
        </span>
      </span>
    </a>
    ";
            // line 38
            if ((($tmp = (($_v0 = ($context["list"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess && in_array($_v0::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v0["#links"] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["list"] ?? null), "#links", [], "array", false, false, true, 38))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 39
                yield "      ";
                yield (string) $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["list"] ?? null), "html", null, true);
                yield "
    ";
            }
            // line 41
            yield "  </div>
";
        }
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["promoted", "paragraph", "view_mode", "localgov_base_remove_css", "attributes", "field_link", "list"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/ssaspb/templates/paragraphs/paragraph--localgov-ia-block.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  97 => 41,  91 => 39,  89 => 38,  80 => 32,  74 => 29,  69 => 28,  67 => 27,  64 => 26,  58 => 24,  56 => 23,  53 => 22,  51 => 19,  50 => 18,  49 => 17,  48 => 15,  47 => 12,  44 => 10,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "themes/custom/ssaspb/templates/paragraphs/paragraph--localgov-ia-block.html.twig", "/Users/harshtrivedi/LocalGov Drupal SCC/ssaspb/web/themes/custom/ssaspb/templates/paragraphs/paragraph--localgov-ia-block.html.twig");
    }
    
    public function ensureSecurityChecked(): void
    {
        if ($this->sandbox->isSandboxed($this->source)) {
            $this->checkSecurity();
        }
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 12, "if" => 23];
        static $filters = ["clean_class" => 17, "escape" => 24];
        static $functions = ["attach_library" => 24];
        static $tests = [];

        try {
            $this->sandbox->checkSecurity(
                [0 => "set", 1 => "if"],
                [0 => "clean_class", 1 => "escape"],
                [0 => "attach_library"],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            } elseif ($e instanceof SecurityNotAllowedTestError && isset($tests[$e->getTestName()])) {
                $e->setTemplateLine($tests[$e->getTestName()]);
            }

            throw $e;
        }

    }
}
